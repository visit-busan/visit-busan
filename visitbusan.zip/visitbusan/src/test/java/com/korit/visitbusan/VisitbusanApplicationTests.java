package com.korit.visitbusan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VisitbusanApplicationTests {

	@Test
	void contextLoads() {
	}

}
